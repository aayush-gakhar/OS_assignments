#!/bin/bash 
cal $1 $2